from django.shortcuts import render
from django.http import HttpResponse
from.models import Contact
# Create your views here.
def contact(request):
    if request.method=='POST':
        name=request.POST['name']
        email=request.POST['email']
        phone=request.POST['phone']
        query=request.POST.get('query','')
        print(name,email,phone)
        contacts=Contact(name=name,email=email,phone=phone,query=query)
        contacts.save()
    return render(request,'contact.html')