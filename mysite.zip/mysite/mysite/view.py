import sympy as sp
#from scipy.integrate import quad
from math import sin, pi, cos, tan, sqrt, acos, asin, atan, log, asinh, acosh, atanh, e, exp

from django.http import HttpResponse
from django.shortcuts import render


def index(request):
     return render(request, 'index.html')
def contact(request):
    return render(request,'contact.html')
def home(request):
    return render(request,'home.html')
def about(request):
     return render(request, 'about.html')

def index1(request):
     return render(request, 'index1.html')


def finite(request):
     text1 = request.POST.get('text', 'off')
     x = sp.Symbol('x')
     y = text1
     try:
          print(sp.integrate(y, x))
          analyze = (sp.integrate(y, x))
          params = {'analyzed_text': analyze}
     except:
          return render(request, 'errors.html')
     else:
          return render(request, 'result.html', params)


def definite(request):
     from scipy.integrate import quad
     from numpy import sin, cos, tan, log, e, exp, log10, pi, sqrt, arccos, arctan, arccosh, arcsin
     text1 = request.POST.get('text', 'default')
     i = compile(text1, 'input', 'eval')
     try:
          def f(x):
               return eval(i)

          a = int(request.POST.get('upper', 'default'))
          b = int(request.POST.get('lower', 'default'))
          j = quad(f, a, b)
          inte = j[0]
          params = {'analyzed_text': inte}
     except:
          return render(request, 'errors.html')
     else:
         return render(request, 'result.html', params)
